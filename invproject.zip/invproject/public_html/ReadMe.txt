Hello Users
Dont forget to like and comment in webscript.info projects source code





-----------------------------------
STEPS
----------------------------------
Download the project from webscript.info
Extract the project folder in your server folder such as xampp/htdocs or wamp/www folder
Open project folder and then open database folder where you will see inv_project.sql file
Open your phpmyadmin create a database with name project_inv 
select your database
click on import file and then select inv_project.sql file then click on go
Now you are ready to run index file
Good luck




