<?php
session_start();
include_once("../fpdf/fpdf.php");

if (isset($_GET["order_date"]) && isset($_GET["cust_name"])) {
    // Read the current bill number from a file or database
    $billNumberFile = "../bill_number.txt";
    $currentBillNumber = intval(file_get_contents($billNumberFile));

    // Increment the bill number by 1
    $billNumber = $currentBillNumber + 1;

    // Save the updated bill number back to the file or database
    file_put_contents($billNumberFile, $billNumber);

    // Rest of the code remains the same
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont("Arial", "B", 30);
    $pdf->Cell(190, 10, "ROYAL GARMENTS", 0, 1, "C");
    $pdf->setFont("Arial", null, 12);
    $pdf->Cell(50, 10, "Sakhre Complex, Mohammad Ali Road, Opp.Itwara Police Station, Nanded. Mob No: +919637867808", 0, 1);
    $pdf->SetLineWidth(0.5);
    $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 190, $pdf->GetY());
    $pdf->Ln(10);
    $pdf->SetFont("Arial", null, 14);
    $pdf->Cell(50, 10, "Bill Number", 0, 0);
    $pdf->Cell(50, 10, ": " . $billNumber, 0, 1);
    $pdf->Cell(50, 10, "Date", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["order_date"], 0, 1);
    $pdf->Cell(50, 10, "Customer Name", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["cust_name"], 0, 1);


    $pdf->Cell(50, 10, "", 0, 1);

    $pdf->Cell(10, 10, "#", 1, 0, "C");
    $pdf->Cell(70, 10, "Product Name", 1, 0, "C");
    $pdf->Cell(30, 10, "Quantity", 1, 0, "C");
    $pdf->Cell(40, 10, "Price", 1, 0, "C");
    $pdf->Cell(40, 10, "Total (Rs)", 1, 1, "C");

    for ($i = 0; $i < count($_GET["pid"]); $i++) {
        $pdf->Cell(10, 10, ($i + 1), 1, 0, "C");
        $pdf->Cell(70, 10, $_GET["pro_name"][$i], 1, 0, "C");
        $pdf->Cell(30, 10, $_GET["qty"][$i], 1, 0, "C");
        $pdf->Cell(40, 10, $_GET["price"][$i], 1, 0, "C");
        $pdf->Cell(40, 10, ($_GET["qty"][$i] * $_GET["price"][$i]), 1, 1, "C");
    }

    $pdf->Cell(50, 10, "", 0, 1);

    $pdf->Cell(50, 10, "Sub Total", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["sub_total"], 0, 1);
    $pdf->Cell(50, 10, "Gst Tax", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["gst"], 0, 1);
    $pdf->Cell(50, 10, "Discount(%)", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["discount"], 0, 1);
    $pdf->Cell(50, 10, "Net Total", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["net_total"], 0, 1);
    $pdf->Cell(50, 10, "Paid", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["paid"], 0, 1);
    $pdf->Cell(50, 10, "Due Amount", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["due"], 0, 1);
    $pdf->Cell(50, 10, "Payment Type", 0, 0);
    $pdf->Cell(50, 10, ": " . $_GET["payment_type"], 0, 1);

    $pdf->Cell(180, 10, "Signature", 0, 0, "R");


    $custName = $_GET["cust_name"];
    $currentDate = date("d M Y");
    $pdfFilePath = "../PDF_INVOICE/{$billNumber}_{$custName}_{$currentDate}.pdf";

    $pdf->Output($pdfFilePath, "F");
    echo "PDF invoice generated and saved successfully.";
}
?>
